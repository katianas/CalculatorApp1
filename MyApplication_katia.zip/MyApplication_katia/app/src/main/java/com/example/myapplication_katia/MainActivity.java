package com.example.myapplication_katia;

import androidx.appcompat.app.AppCompatActivity;
import org.mariuszgromada.math.mxparser.*;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
private EditText display;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        display =findViewById(R.id.input);
    }
    public void updateText(String strtoAdd){
     String oldstr=display.getText().toString(); // string already written
     int cursorPos=display.getSelectionStart();// the first position
     String leftstr =oldstr.substring(0,cursorPos);// string from position 0 to the current position
     String rightstr=oldstr.substring(cursorPos); // string in the current position

     if(getString(R.string.display).equals(display.getText().toString()))// if the string is the same string in display
         // add the new string in the place of the string in display
     {
         display.setText(strtoAdd);
        display.setSelection(cursorPos=1);
     }
     else { // if not add it next to him
         display.setText(String.format("%s%s%s",leftstr,strtoAdd,rightstr));
         display.setSelection(cursorPos+1);
     }

    }
    public void zeroBTN(View view){
         updateText("0");
    }
    public void oneBTN(View view){
        updateText("1");

    }
    public void twoBTN(View view){
        updateText("2");

    }
    public void threeBTN(View view){
        updateText("3");

    }
    public void fourBTN(View view){
        updateText("4");

    }
    public void fiveBTN(View view){
        updateText("5");

    }
    public void sixBTN(View view){
        updateText("6");

    }
    public void sevenBTN(View view){
        updateText("7");

    }
    public void eightBTN(View view){
        updateText("8");

    }
    public void nineBTN(View view){
        updateText("9");

    }
    public void clearBTN(View view){
          display.setText(" ");
    }
    public void expBTN(View view){
        updateText("^");

    }
    public void parentBTN(View view){
       int cursorPos=display.getSelectionStart();
       int openpar=0;
       int closespar=0;
       int textlen=display.getText().length(); // the length of the string

       for(int i=0;i<cursorPos;i++)
       {
           if(display.getText().toString().substring(i,i+1).equals("("))
               openpar+=1;
           if(display.getText().toString().substring(i,i+1).equals(")"))
               closespar+=1;
       }

       if(openpar==closespar || display.getText().toString().substring(textlen-1,textlen).equals("(")){
           updateText("(");
       display.setSelection(cursorPos+1);
       }
       else if (closespar<openpar && !display.getText().toString().substring(textlen-1,textlen).equals(")"))
       {
           updateText(")");
           display.setSelection(cursorPos+1);
       }

    }
    public void divideBTN(View view){
        updateText("%");

    }
    public void moltiBTN(View view){
        updateText("x");

    }
    public void addBTN(View view){
        updateText("+");

    }
    public void subBTN(View view){
        updateText("-");

    }
    public void plusMinusBTN(View view){
        updateText("-");

    }
    public void equalsBTN(View view){
        String userexp=display.getText().toString();
        userexp=userexp.replaceAll("%","/");
        userexp=userexp.replaceAll("x","*");

        Expression exp=new Expression(userexp);

        String result=String.valueOf(exp.calculate());

        display.setText(result);
        display.setSelection(result.length());

    }
    public void pointBTN(View view){
        updateText(".");

    }
    public void backspaceBTN(View view){
        
      int cursorPose=display.getSelectionStart(); // the first position
      int textLen=display.getText().length(); //length of the string
        if(cursorPose!=0 && textLen!=0)
        {
            SpannableStringBuilder selection= (SpannableStringBuilder) display.getText();
            selection.replace(cursorPose-1,cursorPose,"");
            display.setText(selection);
            display.setSelection(cursorPose-1);
        }

    }

}